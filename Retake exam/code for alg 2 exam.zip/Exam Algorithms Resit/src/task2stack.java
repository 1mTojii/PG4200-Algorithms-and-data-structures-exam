//You are given N elements , and your task is to Implement a Stack in which you can get a minimum element in O(1)
//time. You are required to complete the three methods:
//o push() which takes one argument, an integer 'x' to be pushed into the stack,
//o pop() which returns an integer popped out from the stack, and
//o getMin() which returns the min element from the stack. (-1 will be returned if for pop() and getMin() the
//stack is empty.)
//o Constraints:
//1 <= Number of queries <= 100
//1 <= values of the stack <= 100

import java.util.Scanner;

public class task2stack {


    int [] stack; //hold the stacks values
    int [] minOfStack; // minimum of stack
    int topOfStack; // top of the stack

    public task2stack(){
        int capacity = 100; //max pushes no more pushes can be done
        stack = new int[capacity];
        minOfStack = new int[capacity];
        topOfStack = -1; // shows the stacks empty
    }

    //small helper method that helps the program from crashing
    public int remaining () {
        return stack.length - (topOfStack + 1);
    }


    // the push method
    public void push(int a){

        //simple helper if statment to help from crashing
        if (topOfStack == stack.length-1){
            System.out.println("Stack is full" + a);
            return;
        }

        topOfStack++;
        stack[topOfStack] = a;

        if (topOfStack == 0) {
            minOfStack[topOfStack] = a;
        } else {
            minOfStack[topOfStack] = Math.min(minOfStack[topOfStack - 1], a );
        }
    }//end of push

    //pop method
    public int pop(){
        if (topOfStack == -1){
            System.out.println("Stack is empty");
            return -1;
        }
        int a = stack[topOfStack];
        topOfStack--;
        return a;
    }// end og pop method

    //returns the minimum element. If the stacks empty it returns -1
    public int getMin(){
        if (topOfStack == -1){
            System.out.println("Stack is empty");
            return -1;
        }
        return minOfStack[topOfStack];
    }

    //helper class for the menu. just prints the current stack
    //not needed just a fun addon that i wanted to add :)
    public void printStack(){
        if (topOfStack == -1){
            System.out.println("Stack is empty");
            return;
        }
        System.out.println("Stack:");
        for (int i = 0; i <= topOfStack; i++) {
            System.out.print(stack[i] + " ");
        }
        System.out.println();
    }


    public static void main(String[] args) {
        task2stack stack = new task2stack();
        Scanner input = new Scanner(System.in);

        System.out.printf("Welcome to my super duper cool stack\n");

        while (true){
            System.out.println("Super crazy cool menu");
            System.out.println("1. push");
            System.out.println("2. pop");
            System.out.println("3. minimum");
            System.out.println("4. printStack");
            System.out.println("5. exit");

            if (!input.hasNext()){
                System.out.println("enter a number from 1 to 5");
                input.next();
                continue;
            }

            int choice = input.nextInt();

            //choice 1
            if (choice == 1){
                System.out.println("Enter element to be pushed into the stack");
                int value = input.nextInt();
                stack.push(value);
                System.out.println("Pushed: " + value + ". Slots left: " + stack.remaining());
            }
            // choice 2
            else if (choice == 2){
                int popped = stack.pop();
                if (popped == -1){
                    System.out.println("Stack is empty");
                } else {
                    System.out.println("Popped: " + popped + ". Slots left: " + stack.remaining());
                }
            }
            // choice 3
            else if (choice == 3){
                int min = stack.getMin();
                if (min == -1){
                    System.out.println("-1");
                } else {
                    System.out.println("Minimum: " + min);
                }
            }
            // choice 4
            else if (choice == 4){
                System.out.println("Here is the stack!! :D");
                stack.printStack();
            }
            // choice 5
            else if (choice == 5){
                System.out.println("Goobyeee (-.-)");
                break;
            } else {
                break;
            }

        }




        }
    }
