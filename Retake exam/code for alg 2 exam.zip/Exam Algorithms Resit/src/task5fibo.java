
//Regardless of how fast computers become or
//how cheap memory gets, efficiency will always remain an important
//consideration. To show the importance of developing efficient algorithms,
//compare these two algorithms:
//Recursive algorithm to solve
//fib(n) for 1 ≤ n ≤ 5 Fibonacci term
//Iterative algorithm to solve
//fib(n) for 1 ≤ n ≤ 5 Fibonacci term
//Justify which algorithm is more efficient and why through the solution with code.


//https://www.baeldung.com/cs/fibonacci-computational-complexity

//https://www.geeksforgeeks.org/dsa/time-complexity-recursive-fibonacci-program

//https://www.geeksforgeeks.org/dsa/fibonacci-series/

//https://stackoverflow.com/questions/39839640/java-fibonacci-sequence-fast-method


public class task5fibo {

    // counts how many times the method has been called upon
    static int recursiveCalls = 0;

    // Recursive Fibonacci
    public static int fibRecursice(int n) {
        recursiveCalls++;
        if (n <= 2) {
            return 1;
        }
        return fibRecursice(n - 1) + fibRecursice(n - 2);
    }

    // Iterative Fibonacci
    public static int fibIterative(int n) {
        if (n <= 2) {
            return 1;
        }
        int previous = 1;
        int current = 1;
        for (int i = 3; i <= n; i++) {
            int next = previous + current;
            previous = current;
            current = next;
        }
        return current;
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            recursiveCalls = 0;
            int r = fibRecursice(i);
            int c = recursiveCalls;
            int it = fibIterative(i);
            int loops = (i <= 2) ? 0 : i - 2;
            System.out.println("n, "+ i + " | fib(n), " + r + " | recursive calls, " + c
                    + " | iterative loops, " + loops + " | fibIterations, " + it);
        }
        recursiveCalls = 0;
        fibRecursice(30);
        System.out.println("\nFor fib(30):");
        System.out.println("recursive calls = " + recursiveCalls);
        System.out.println("iterative calls = " + (30 - 2));

    }

}
